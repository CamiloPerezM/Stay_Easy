package DH.Integrador.Grupo6.ProyectoX_API.Exceptions;

public class BadRequest extends Exception {
    public BadRequest(String message) {
        super(message);
    }
}
