package DH.Integrador.Grupo6.ProyectoX_API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoXApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
