package DH.Integrador.Grupo6.ProyectoX_API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class

ProyectoXApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoXApiApplication.class, args);
	}

}
